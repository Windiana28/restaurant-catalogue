/* eslint-disable no-unused-vars */
import TheRestaurantDBSource from '../../data/therestaurantdb-source';
import { createRestaurantItemTemplate } from '../templates/template';

const restaurant = {
  async render() {
    return `
    <div class="content">
        <h2 class="content_heading">List of Restaurants</h2>
        <div id="restaurants" class="restaurants">
        </div>
      </div>
        `;
  },

  async afterRender() {
    const restaurants = await TheRestaurantDBSource.RestaurantsList();
    const restaurantsContainer = document.querySelector('#restaurants');
    restaurants.forEach((resto) => {
      restaurantsContainer.innerHTML += createRestaurantItemTemplate(resto);
    });
}
}

export default restaurant;
